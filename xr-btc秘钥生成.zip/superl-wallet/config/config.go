

package config

const (
	BitcoinMainNetVersion = byte(0x00) // PubKeyHashAddrID  Base58 prefix=
	AddressChecksumLen    = 4
	BitcoinKeyWIFPrefix   = byte(0x80) // Base58 prefix=5,K,L
)
