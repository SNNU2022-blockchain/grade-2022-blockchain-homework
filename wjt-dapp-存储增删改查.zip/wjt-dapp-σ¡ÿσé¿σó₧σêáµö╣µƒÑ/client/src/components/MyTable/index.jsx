import { useEffect, useState } from "react";
import React from 'react';
import useEth from "../../contexts/EthContext/useEth";
import {Table, Button} from 'antd';

function MyTable() {
  const { state: { contract, accounts } } = useEth();
  const [array, setArray] = useState([]);


  useEffect(() => {
    const init = async() => {
      const value = await contract.methods.getAllValues().call({ from: accounts[0] });
      setArray(handleItem(value));
    }
    if (contract) {
      init();
    }
  }, [contract])

  const handleItem = (arr) => {
    return arr.map((item, index) => {
      return {
        index: index,
        value: item
      }
    })
  }


  const columns = [
    {
      title: 'Index',
      dataIndex: 'index',
      key: 'index',
    },
    {
      title: 'Value',
      dataIndex: 'value',
      key: 'value',
    },
    {
      title: 'Action',
      dataIndex: 'index',
      key: 'action',
      render: (index) => (<Button type="dashed" danger onClick={() => delValue(index)}>del</Button>)
    },
  ];

  const addValue = async () => {
    await contract.methods.addValue(array.length + 1).send({ from: accounts[0] });
    const value = await contract.methods.getAllValues().call({ from: accounts[0] });
    setArray(handleItem(value));
  }

  const delValue = async (index) => {
    await contract.methods.deleteValue(index).send({ from: accounts[0] });
    const value = await contract.methods.getAllValues().call({ from: accounts[0] });
    setArray(handleItem(value));
  }

  return (
    <>
      <div style={{width: '100%', marginBottom: '24px'}}>
        <Button type="primary" onClick={addValue}>Add Item</Button>
      </div>
      {array.length <= 0 ? '列表为空' : <Table columns={columns} dataSource={array} />}
      
    </>
  );
}

export default MyTable;
