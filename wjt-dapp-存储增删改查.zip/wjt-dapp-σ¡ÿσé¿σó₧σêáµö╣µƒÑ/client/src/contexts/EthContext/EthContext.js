import { createContext } from "react";

const EthContext = createContext();

export default EthContext;
