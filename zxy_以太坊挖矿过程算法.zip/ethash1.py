import sys
import hashlib
from random import randint

if sys.version_info < (3,6):
	import sha3
import copy

WORD_BYTES=4     #单词字节数
DATASET_BYTES_INIT=2**30     #创世时数据集中的字节数，
DATASET_BYTES_GROWTH=2**23   #每个epoch数据集的增长
CACHE_BYTES_INIT=2**24       #创世时每个cache中的字节数目
CACHE_BYTES_GROWTH=2**17     #每个epoch缓存的增长大小
CACHE_MULTIPLIER=1024        #cache生成的DAG大小
EPOCH_LENGTH=30000           #每个epoch中块的数目
MIX_BYTES=128                #Mix的宽度
HASH_BYTES=64                #哈希长度字节大小
DATASET_PARENTS=256          #每个数据集的父元素数量
CACHE_ROUND=3                #cache生成的回合数目
ACCESS=64                    #hashimoto中的循环访问次数

class Block:
	def __init__(self,number,nonce):
		self.number=number
		self.nonce=nonce 
		#self.seed=seed

	def printblock(self):
		print("当前区块编号值是：")
		print(self.number)
		print("nonce值是：")
		print(self.nonce)
		# print("seed值为：")
		# print(self.seed)
		#"\nnonce值为"+self.nonce+"\nseed值为："+self.seed)


#Ethash的缓存和数据集的参数取决于区块号。cache和dataset大小都呈现线性增长，但取低于线性增长阈值的最高素数，以降低意外规律导致循环行为的风险

def decode_int(s):
	return int(s[::-1].encode('hex'),16) if s else 0

def encode_int(s):
	a="%x"%s
	return '' if s==0 else ('0'*(len(a)%2)+a).decode('hex')[::-1]

def zpad(s,length):
	return s+'\x00'*max(0,length-len(s)) #空格字符，长度为1

def serialize_hash(h):
	return ''.join([zpad(encode_int(x),4) for x in h])

def deserialize_hash(h):
	return [decode_int(h[i:i+WORD_BYTES]) for i in range(0,length(h),WORD_BYTES)]

def hash_words(h,sz,x):
	if isinstance(x,list):
		x=serialize_hash(x)
	y=h(x)
	return deserialize_hash(y)

def serialize_cache(ds):
	return ''.join([serialize_hash(h) for h in ds])

serialize_dataset=serialize_cache

#SHA3哈希函数，输出64字节
def sha3_512(x):
	return hash_words(lambda v:sha3.sha3_512(v).digest(),64,x)

def sha3_256(x):
	return hash_words(lambda v:sha3.sha3_256(v).digest(),32,x)

def xor(a,b):
	return a^b

def isprime(x):
	for i in range(2,int(x**0.5)):
		if x%i==0:
			return False
	return True
def get_cache_size(block_number):
	size=CACHE_BYTES_INIT+CACHE_BYTES_GROWTH*(block_number//EPOCH_LENGTH) 
	#cache最初大小加上增长乘以经过的epoch数目
	size-=HASH_BYTES
	while not isprime(size/HASH_BYTES):
		size-=2*HASH_BYTES
	return size

def get_full_size(block_number):
	size=DATASET_BYTES_INIT+DATASET_BYTES_GROWTH*(block_number//EPOCH_LENGTH)
	size-=MIX_BYTES
	while not isprime(size/MIX_BYTES):
		size-=2*MIX_BYTES
	return size

#指定生成缓存的函数，使用seed计算cache

def mkcache(cache_size,seed):
	n=cache_size//HASH_BYTES
	#依次产生初始数据集
	init_dataset=[sha3_512(seed)]
	for i in range(1,n):
		init_dataset.append(sha3_512(init_dataset[-1]))

	#使用低轮版本的randmemohash
	for _ in range(CACHE_ROUND):
		for i in range(n):
			v=init_dataset[i][0]%n
			init_dataset[i]=sha3_512(map(xor,init_dataset[(i-1+n)%n],init_dataset[v]))

	return init_dataset

'''缓存生成过程中，先按照顺序填充32MB内存，然后从严格内存硬哈希函数执行两次
sergio Demian Lerner的RandMemoHAsh算法，输出一组524288个64字节值

数据聚合函数
使用灵感来自FNV哈希的算法，在部分情况下，这种算法可用作逻辑异或的不相关代替。
使用全32位输入乘以素数'''
FNV_PRIME=0x01000193

def fnv(v1,v2):
	return ((v1*FNV_PRIME)^v2)%2**32

#完整数据集计算
#整个1GB数据集中每个64字节项目的计算如下：
def calc_dataset_item(cache,i):
	n=len(cache)
	r=HASH_BYTES//WORD_BYTES
	#初始化mix
	mix=copy.copy(cache[i%n])
	mix=sha3_512(mix)
	#fnv 用大量基于i的随机缓存节点fnv它，
	#为了保证每个初始的mix点不同，用i参与计算来控制其变得不同
	#每个数据集中parents的数目为256，因而进行256次循环
	for j in range(DATASET_PARENTS):
		#根据当前mix的值求得下一个要访问的cache的下标
		cache_index=fnv(i^j,mix[j%r])
		mix=map(fnv,mix,cache[cache_index%n])
	return sha3_512(mix)
	#返回mix的哈希值，得到第i个dataset中的元素，多次调用此函数
	#就可以得到完整的dataset

#将来自256个随机选择的缓存节点的数据聚集起来求哈希值，以计算数据集节点，然后生成整个数据集
#不断调用前面那个函数来依次生成dataset中的全部元素

def calc_dataset(full_size,cache):
	return [calc_dataset_item(cache,i) for i in range(full_size//HASH_BYTES)]

'''主循环，聚合了整个数据集的数据，以生成特定区块头和随机数的最终值。
header代表被截断区块头的递归长度前缀表示的SHA3-256哈希值。
被截断是指区块头被截去了mixHash和随机数字段。
nonce是指一个64位无符号整数的八个字节，按照大端序排列。
因此nonce[::-1]是指上述值得八字节小端序表示:'''

def hashimoto(header,nonce,full_size,dataset_lookup):
	n=full_size/HASH_BYTES
	w=MIX_BYTES//WORD_BYTES  #128//32
	mixhashes=MIX_BYTES/HASH_BYTES
	#将header值和nonce值结合成为一个64字节的seed
	new_seed=sha3_512(header+nonce[::-1])
	#用复制的s开始混合
	mix=[]
	for _ in range(MIX_BYTES/HASH_BYTES):
		mix.extend(new_seed)
	#加入mix数据集节点
	#以下循环64次，ACCESS值为64
	for i in range(ACCESS):
		p=fnv(i^new_seed[0],mix[i%w])%(n//mixhashes)*mixhashes
		newdata=[]
		for j in range(MIX_BYTES/HASH_BYTES):
			newdata.extend(dataset_lookup(p+j))
		mix=map(fnv,mix,newdata)
	#压缩mix
	cmix=[]
	for i in range(0,len(mix),4):
		cmix.append(fnv(fnv(fnv(mix[i],mix[i+1]),mix[i+2]),mix[i+3]))
	return {
		"mix digest":serialize_hash(cmix),
		"result":serialize_hash(sha3_256(s+cmix))
	}


def hashimoto_light(full_size,cache,header,nonce):
	return hashimoto(header,nonce,full_size,lambda x:calc_dataset_item(cache,x))
#轻节点临时计算dataset，而矿工直接使用dataset，因为其内存里已经存有

def hashimoto_full(full_size,dataset,header,nonce):
	return hashimoto(header,nonce,full_size,lambda x:dataset[x])

'''基本上保持着一个宽128字节的"mix"，并多次按照顺序从整个数据集中获取128个字节，并使用
fnv函数将其与"mix"结合起来。使用128字节的序列访问，以便每轮算法总是能从随机访问内存获取完整
的页面，从而尽量减少转译后备缓冲区的疏忽，而专用集成电路在理论上能避免这些疏忽
如果此算法的输出低于所需目标，则证明随机数有效。请注意在最后额外应用sha3_256将确保中间数的存在
提供此证据可以证明至少做了少量工作，而且此外快速外部工作量证明验证可以用于反分布式拒绝服务目的，
也可提供统计保证，说明结果是一个无偏256位数字'''


#挖矿算法定义：
def mine(full_size,dataset,header,difficulty):
	#zero-pad是为了对同一数字的哈希值进行比较
	target=zpad(encode_int(2**256//difficulty),64)[::-1]
	from random import randint
	nonce=randint(0,2**64)
	while hashimoto_full(full_size,dataset,header,nonce)>target:
		nonce=(nonce+1)%2**64
		#调整nonce值
	return nonce


#定义种子哈希
#计算用户在给定区块上挖掘的种子哈希值
def get_seedhash(block):
	s='\x00'*32
	for i in range(block.number//EPOCH_LENGTH):
		s=serialize_hash(sha3_256(s))
	return s

# string1="我是第一个字符串"
# print(string1[::-1])
#逆序操作

#pint函数数字可以直接输出
#print里面不要有计算式子
#print(example_block.number)

def get_datasize(block_number):
    return data_sizes[block_number // EPOCH_LENGTH]
#进行整除 abs()取整函数  round()五舍去六进 pow(a,2)a的二次方 print(len(string1)) len获取长度

def get_cachesize(block_number):
    return cache_sizes[block_number // EPOCH_LENGTH]


def main():
	nonce=randint(0,2**64)
	
	example_block=Block(DATASET_BYTES_INIT,nonce)
	seed=get_seedhash(example_block)
	example_block.printblock()


if __name__ == '__main__':
	main()
print("ok")
print(2**3)
print(8//2)